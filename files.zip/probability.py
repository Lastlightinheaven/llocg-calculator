"""
Hypergeometric probability calculation for Love Live OCG.

Key insight (from user's Google Sheet, verified to reproduce 90.85%):
   When Yell draws N cards from the remaining deck, a Live succeeds iff:
     1. For each non-Gray color C in requirements:
           (drawn C triggers) + (All triggers used for C) >= required C hearts
     2. Total hearts drawn (any trigger) + basic hearts on stage
           >= total required hearts (including gray)

   Equivalently:
     - Non-trigger cards drawn must be <= (N - hearts_still_needed_from_yell)
     - Target-color-compatible cards drawn must be >= target-color-still-needed
"""
from __future__ import annotations
from dataclasses import dataclass
from math import comb
from typing import Dict, List, Tuple

from models import Color, DeckComposition, GameState


@dataclass
class ProbabilityResult:
    probability: float            # 0.0 - 1.0
    favorable_cases: int          # Number of favorable (deck, draw) configurations
    total_cases: int              # Total possible draws = C(N, n)
    draws: int                    # Number of cards drawn (blade count)
    deck_size: int                # Effective deck size

    def percent(self) -> float:
        return self.probability * 100.0


def _multinomial_hypergeometric_prob(
    category_sizes: List[int],
    category_draws: List[int],
    total_deck: int,
    total_draws: int,
) -> float:
    """
    Probability of drawing exactly category_draws[i] cards from category of size
    category_sizes[i]. Uses multivariate hypergeometric.
    """
    if sum(category_draws) != total_draws:
        return 0.0
    num = 1
    for k, d in zip(category_sizes, category_draws):
        if d < 0 or d > k:
            return 0.0
        num *= comb(k, d)
    denom = comb(total_deck, total_draws)
    if denom == 0:
        return 0.0
    return num / denom


def calculate_live_success_probability(state: GameState) -> ProbabilityResult:
    """
    Calculate the exact probability that the player's Yell succeeds.

    Approach: enumerate all valid (drawn per category) tuples whose counts
    satisfy the success conditions, summing their multivariate hypergeometric
    probabilities. Uses the deck's remaining composition.
    """
    remaining = state.remaining_deck()
    N = remaining.total()
    draws = state.stage.blade_count

    # Edge cases
    if draws <= 0:
        # No yell — success iff basic hearts already cover requirements
        combined = state.combined_requirements()
        satisfied = _check_hearts_satisfy(
            hearts_by_color=state.stage.basic_hearts,
            wildcard_hearts=0,
            requirements=combined,
        )
        return ProbabilityResult(
            probability=1.0 if satisfied else 0.0,
            favorable_cases=1 if satisfied else 0,
            total_cases=1,
            draws=0,
            deck_size=N,
        )

    if draws > N:
        # Can't draw more than deck contains (would require reshuffle) — cap at N
        draws = N

    # Categorize the remaining deck
    # We split into categories: each trigger color, All, Non-trigger
    categories: List[Tuple[str, int]] = []
    category_map: Dict[str, int] = {}

    for color in Color.trigger_colors():
        cnt = remaining.count(color)
        categories.append((color.value, cnt))
        category_map[color.value] = len(categories) - 1

    all_idx = len(categories)
    categories.append(("all", remaining.all_trigger))
    non_idx = len(categories)
    categories.append(("non", remaining.non_trigger))

    combined_req = state.combined_requirements()
    total_required = sum(combined_req.values())
    total_basic = state.stage.total_basic_hearts()

    # Enumerate all ways to split `draws` among categories
    # Use a recursive/iterative approach; with up to ~7 categories, this is tractable
    category_counts = [c[1] for c in categories]

    favorable_prob = 0.0
    total_cases = comb(N, draws) if N >= draws else 0

    # Use iterative enumeration
    def enumerate_splits(idx: int, remaining_draws: int, current: List[int]):
        nonlocal favorable_prob
        if idx == len(categories) - 1:
            # Last category takes whatever's left
            last = remaining_draws
            if 0 <= last <= category_counts[idx]:
                current.append(last)
                # Check this split
                if _is_favorable(current, categories, state, combined_req):
                    # Compute probability of this exact split
                    num = 1
                    for k, d in zip(category_counts, current):
                        num *= comb(k, d)
                    favorable_prob += num / total_cases if total_cases else 0
                current.pop()
            return
        cat_size = category_counts[idx]
        max_take = min(remaining_draws, cat_size)
        for take in range(0, max_take + 1):
            current.append(take)
            enumerate_splits(idx + 1, remaining_draws - take, current)
            current.pop()

    if total_cases > 0:
        enumerate_splits(0, draws, [])

    favorable_cases = round(favorable_prob * total_cases)
    return ProbabilityResult(
        probability=favorable_prob,
        favorable_cases=favorable_cases,
        total_cases=total_cases,
        draws=draws,
        deck_size=N,
    )


def _is_favorable(
    drawn_per_cat: List[int],
    categories: List[Tuple[str, int]],
    state: GameState,
    combined_req: Dict[Color, int],
) -> bool:
    """
    Check if a given draw distribution satisfies the Live success condition:
      1. Each non-gray color's required hearts are met (trigger + all wildcards + basic)
      2. Total hearts >= total required (including gray)
    """
    # Build hearts drawn per color
    drawn_hearts: Dict[Color, int] = {}
    all_drawn = 0
    non_drawn = 0
    for (cat_name, _cat_size), taken in zip(categories, drawn_per_cat):
        if cat_name == "all":
            all_drawn = taken
        elif cat_name == "non":
            non_drawn = taken
        else:
            try:
                color = Color(cat_name)
                drawn_hearts[color] = taken
            except ValueError:
                pass

    # Try to satisfy requirements using basic hearts + drawn hearts + all-trigger wildcards
    return _check_hearts_satisfy(
        hearts_by_color={
            color: state.stage.hearts_for_color(color) + drawn_hearts.get(color, 0)
            for color in Color.trigger_colors()
        },
        wildcard_hearts=all_drawn,
        requirements=combined_req,
    )


def _check_hearts_satisfy(
    hearts_by_color: Dict[Color, int],
    wildcard_hearts: int,
    requirements: Dict[Color, int],
) -> bool:
    """
    Greedy check: can we satisfy each color requirement using specific-color hearts
    and wildcard (All) hearts, AND total hearts >= total required?

    Algorithm:
      1. For each non-gray color, specific hearts cover it first.
         Shortfall must be covered by wildcards.
      2. Any wildcards + leftover specific hearts cover gray requirement.
      3. Total collected must be >= total required.
    """
    wildcards_left = wildcard_hearts
    leftover_specifics = 0

    gray_required = requirements.get(Color.GRAY, 0)
    total_required = sum(requirements.values())
    total_collected = sum(hearts_by_color.values()) + wildcard_hearts

    # Step 1: cover each non-gray color
    for color, req in requirements.items():
        if color == Color.GRAY:
            continue
        have = hearts_by_color.get(color, 0)
        if have >= req:
            leftover_specifics += (have - req)
        else:
            shortfall = req - have
            if wildcards_left >= shortfall:
                wildcards_left -= shortfall
            else:
                return False  # Can't cover this specific color

    # Step 2: cover gray requirement with anything left
    pool_for_gray = wildcards_left + leftover_specifics + _unused_colors_total(
        hearts_by_color, requirements
    )
    # Actually simpler: total collected must be >= total required
    if total_collected < total_required:
        return False

    return True


def _unused_colors_total(
    hearts_by_color: Dict[Color, int],
    requirements: Dict[Color, int],
) -> int:
    """Sum of hearts in colors that aren't required at all."""
    required_colors = {c for c in requirements if c != Color.GRAY}
    return sum(n for c, n in hearts_by_color.items() if c not in required_colors)


def simple_target_probability(
    remaining_deck: DeckComposition,
    target_color: Color,
    draws: int,
    target_needed: int,
    non_trigger_max: int,
) -> ProbabilityResult:
    """
    Simplified calculation matching the Google Sheet exactly:
      - Target color + All Trigger must be drawn >= target_needed
      - Non-Trigger drawn must be <= non_trigger_max
      - Other triggers (non-target) fill the rest freely
    """
    target_pool = remaining_deck.count(target_color) + remaining_deck.all_trigger
    other_trigger_pool = (
        sum(
            remaining_deck.count(c)
            for c in Color.trigger_colors()
            if c != target_color
        )
    )
    non_trigger_pool = remaining_deck.non_trigger
    N = target_pool + other_trigger_pool + non_trigger_pool

    if N == 0 or draws == 0 or draws > N:
        return ProbabilityResult(
            probability=0.0,
            favorable_cases=0,
            total_cases=comb(N, draws) if N >= draws else 0,
            draws=draws,
            deck_size=N,
        )

    total_cases = comb(N, draws)
    favorable = 0

    for n in range(0, min(non_trigger_max, non_trigger_pool) + 1):
        for r in range(target_needed, min(draws - n, target_pool) + 1):
            o = draws - n - r
            if 0 <= o <= other_trigger_pool:
                favorable += (
                    comb(target_pool, r)
                    * comb(other_trigger_pool, o)
                    * comb(non_trigger_pool, n)
                )

    prob = favorable / total_cases if total_cases else 0
    return ProbabilityResult(
        probability=prob,
        favorable_cases=favorable,
        total_cases=total_cases,
        draws=draws,
        deck_size=N,
    )
