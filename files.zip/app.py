"""
Love Live OCG - Live Success Probability Calculator
Streamlit web app for calculating the probability of successfully performing
a Live given a player's deck, cards already used, members on stage, and Live requirements.
"""
import streamlit as st
import pandas as pd

from models import (
    Color, COLOR_LABELS_TH, COLOR_EMOJI,
    DeckComposition, WaitingRoom, LiveRequirement,
    StageMembers, GameState,
)
from probability import calculate_live_success_probability
from simulator import simulate_live


st.set_page_config(
    page_title="LLOCG Live Probability Calculator",
    page_icon="🎤",
    layout="wide",
)


# ---------- Helpers ----------
HEART_COLORS = [Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.PURPLE, Color.PINK]


def color_label(color: Color) -> str:
    return f"{COLOR_EMOJI[color]} {COLOR_LABELS_TH[color]}"


# ---------- Header ----------
st.title("🎤 LLOCG Live Probability Calculator")
st.caption(
    "เครื่องมือคำนวณโอกาสเล่น Live สำเร็จ สำหรับเกม Love Live! Official Card Game · "
    "พัฒนาโดยใช้ Hypergeometric Distribution + Monte Carlo Simulation"
)

with st.expander("ℹ️ วิธีใช้งาน / How to use"):
    st.markdown("""
    1. **กรอก Deck** ที่ช่องทางซ้าย — ระบุจำนวนการ์ดแต่ละสี, All Trigger (wildcard), และ Non-Trigger (รวมต้อง 60 ใบ)
    2. **กรอก Waiting Room** — การ์ดที่ออกจาก Deck ไปแล้ว (เช่น Member ที่เรียกออกมาแล้ว, Live ที่เล่นไปแล้ว, หรือ Yell ที่เปิดรอบก่อน)
    3. **กรอก Stage Members** — Basic hearts ที่มีบนเวที + จำนวน Blade รวม (= จำนวนที่จะจั่วตอน Yell)
    4. **เพิ่ม Live Card(s)** — Live ที่จะเล่นในเทิร์นนี้ (สูงสุด 3) พร้อม required hearts
    5. กด **คำนวณ** เพื่อดูผล

    **หลักการ:** Live สำเร็จเมื่อ (1) หัวใจแต่ละสีที่ไม่ใช่สีเทาครบตามต้องการ และ (2) หัวใจรวมทั้งหมด ≥ required hearts รวม

    **สี Gray** = wildcard requirement (หัวใจสีอะไรก็เติมช่องนี้ได้)
    **All Trigger** = wildcard reward (การ์ดใน deck ที่เมื่อเปิดออกมาใน Yell จะนับเป็นหัวใจสีอะไรก็ได้)
    """)

st.divider()

# ==========================================================================
# SIDEBAR: Deck composition
# ==========================================================================
with st.sidebar:
    st.header("🃏 Deck Composition")
    st.caption("Deck ของคุณ (รวม 60 ใบ)")

    # Initialize session state with the Google Sheet example
    if "deck_red" not in st.session_state:
        st.session_state.deck_red = 26
        st.session_state.deck_blue = 0
        st.session_state.deck_green = 0
        st.session_state.deck_yellow = 14
        st.session_state.deck_purple = 5
        st.session_state.deck_pink = 0
        st.session_state.deck_all = 8
        st.session_state.deck_non = 7

    st.subheader("Trigger Hearts by Color")
    deck_red = st.number_input(color_label(Color.RED), min_value=0, max_value=60, key="deck_red")
    deck_blue = st.number_input(color_label(Color.BLUE), min_value=0, max_value=60, key="deck_blue")
    deck_green = st.number_input(color_label(Color.GREEN), min_value=0, max_value=60, key="deck_green")
    deck_yellow = st.number_input(color_label(Color.YELLOW), min_value=0, max_value=60, key="deck_yellow")
    deck_purple = st.number_input(color_label(Color.PURPLE), min_value=0, max_value=60, key="deck_purple")
    deck_pink = st.number_input(color_label(Color.PINK), min_value=0, max_value=60, key="deck_pink")

    st.subheader("Special")
    deck_all = st.number_input(f"{COLOR_EMOJI[Color.ALL]} All Trigger (wildcard)",
                               min_value=0, max_value=60, key="deck_all")
    deck_non = st.number_input("⬛ Non-Trigger", min_value=0, max_value=60, key="deck_non")

    deck = DeckComposition(
        trigger_counts={
            Color.RED: deck_red, Color.BLUE: deck_blue, Color.GREEN: deck_green,
            Color.YELLOW: deck_yellow, Color.PURPLE: deck_purple, Color.PINK: deck_pink,
        },
        all_trigger=deck_all,
        non_trigger=deck_non,
    )

    total = deck.total()
    if total == 60:
        st.success(f"✅ Deck total = {total}")
    else:
        st.error(f"⚠️ Deck total = {total} (ต้องเท่ากับ 60)")

    st.divider()
    st.markdown(
        "[📖 เลือกการ์ดจาก LLOCG Thai DB →](https://llocg-th.vercel.app/cards)",
        unsafe_allow_html=False,
    )


# ==========================================================================
# MAIN: Game state
# ==========================================================================
col1, col2 = st.columns(2)

with col1:
    st.header("🗑️ Waiting Room")
    st.caption("การ์ดที่ออกจาก Deck ไปแล้ว (Waiting Room / Stage / Live สำเร็จ)")

    wr_red = st.number_input(color_label(Color.RED), min_value=0, max_value=60, key="wr_red", value=15)
    wr_blue = st.number_input(color_label(Color.BLUE), min_value=0, max_value=60, key="wr_blue", value=0)
    wr_green = st.number_input(color_label(Color.GREEN), min_value=0, max_value=60, key="wr_green", value=0)
    wr_yellow = st.number_input(color_label(Color.YELLOW), min_value=0, max_value=60, key="wr_yellow", value=10)
    wr_purple = st.number_input(color_label(Color.PURPLE), min_value=0, max_value=60, key="wr_purple", value=3)
    wr_pink = st.number_input(color_label(Color.PINK), min_value=0, max_value=60, key="wr_pink", value=0)
    wr_all = st.number_input(f"{COLOR_EMOJI[Color.ALL]} All Trigger",
                             min_value=0, max_value=60, key="wr_all", value=3)
    wr_non = st.number_input("⬛ Non-Trigger", min_value=0, max_value=60, key="wr_non", value=4)

    waiting = WaitingRoom(
        trigger_counts={
            Color.RED: wr_red, Color.BLUE: wr_blue, Color.GREEN: wr_green,
            Color.YELLOW: wr_yellow, Color.PURPLE: wr_purple, Color.PINK: wr_pink,
        },
        all_trigger=wr_all,
        non_trigger=wr_non,
    )
    wr_total = waiting.total()
    st.info(f"การ์ดที่ออกจาก Deck = **{wr_total}** ใบ | คงเหลือใน Deck = **{total - wr_total}** ใบ")


with col2:
    st.header("🎭 Stage Members")
    st.caption("Basic Hearts บนเวที + จำนวน Blade รวม")

    blade_count = st.number_input(
        "🔋 จำนวน Blade รวม (= จำนวนการ์ดที่จะจั่วใน Yell)",
        min_value=0, max_value=60, value=10, key="blade_count",
    )

    st.markdown("**Basic Hearts** (หัวใจที่ได้แน่จาก Member บนเวที)")

    sb_red = st.number_input(color_label(Color.RED), min_value=0, max_value=30, key="sb_red", value=0)
    sb_blue = st.number_input(color_label(Color.BLUE), min_value=0, max_value=30, key="sb_blue", value=0)
    sb_green = st.number_input(color_label(Color.GREEN), min_value=0, max_value=30, key="sb_green", value=0)
    sb_yellow = st.number_input(color_label(Color.YELLOW), min_value=0, max_value=30, key="sb_yellow", value=0)
    sb_purple = st.number_input(color_label(Color.PURPLE), min_value=0, max_value=30, key="sb_purple", value=0)
    sb_pink = st.number_input(color_label(Color.PINK), min_value=0, max_value=30, key="sb_pink", value=0)

    stage = StageMembers(
        basic_hearts={
            Color.RED: sb_red, Color.BLUE: sb_blue, Color.GREEN: sb_green,
            Color.YELLOW: sb_yellow, Color.PURPLE: sb_purple, Color.PINK: sb_pink,
        },
        blade_count=blade_count,
    )
    st.info(f"Basic Hearts รวม = **{stage.total_basic_hearts()}** | Yell draws = **{blade_count}**")


st.divider()

# ==========================================================================
# LIVE CARDS
# ==========================================================================
st.header("🎵 Live Card(s) ที่จะเล่น")
st.caption("กำหนด required hearts ของ Live แต่ละใบ (สูงสุด 3 Live ต่อเทิร์น)")

# Number of lives
if "n_lives" not in st.session_state:
    st.session_state.n_lives = 1

col_nl, _ = st.columns([1, 3])
with col_nl:
    n_lives = st.selectbox("จำนวน Live ที่จะเล่น", options=[1, 2, 3], key="n_lives")

# Defaults for Google Sheet example
defaults = [
    {"name": "Live 1", "hearts": {Color.RED: 5, Color.GRAY: 3}},
    {"name": "Live 2", "hearts": {Color.PURPLE: 1, Color.GRAY: 1}},
    {"name": "Live 3", "hearts": {Color.YELLOW: 2, Color.GRAY: 2}},
]

lives = []
live_cols = st.columns(n_lives)
for i in range(n_lives):
    with live_cols[i]:
        st.subheader(f"Live #{i+1}")
        name = st.text_input("ชื่อ Live", value=defaults[i]["name"], key=f"live_name_{i}")
        req = {}
        for color in HEART_COLORS + [Color.GRAY]:
            val = defaults[i]["hearts"].get(color, 0) if i < len(defaults) else 0
            n = st.number_input(
                color_label(color),
                min_value=0, max_value=20,
                value=val,
                key=f"live_{i}_{color.value}",
            )
            if n > 0:
                req[color] = n
        lives.append(LiveRequirement(name=name, required_hearts=req))

# Summary of combined requirements
combined_req: dict = {}
for lv in lives:
    for c, n in lv.required_hearts.items():
        combined_req[c] = combined_req.get(c, 0) + n
if combined_req:
    summary = "  ".join(
        f"{color_label(c)}: **{n}**"
        for c, n in combined_req.items()
    )
    st.info(f"Required hearts รวม: {summary}  |  Total = **{sum(combined_req.values())}**")


st.divider()

# ==========================================================================
# CALCULATE
# ==========================================================================
state = GameState(deck=deck, waiting_room=waiting, stage=stage, lives=lives)

col_btn1, col_btn2 = st.columns([1, 3])
with col_btn1:
    calc_btn = st.button("🎲 คำนวณความน่าจะเป็น", type="primary", use_container_width=True)
with col_btn2:
    run_mc = st.checkbox("รัน Monte Carlo Simulation ด้วย", value=True)
    mc_trials = st.select_slider(
        "จำนวน trials (Monte Carlo)",
        options=[1_000, 5_000, 10_000, 20_000, 50_000, 100_000],
        value=20_000,
    )

if calc_btn:
    errors = deck.validate()
    if errors:
        for e in errors:
            st.error(e)
    elif not combined_req:
        st.warning("กรุณากรอก required hearts ของ Live อย่างน้อย 1 ใบ")
    else:
        st.subheader("📊 ผลการคำนวณ")

        remaining = state.remaining_deck()
        col_r1, col_r2, col_r3 = st.columns(3)
        col_r1.metric("การ์ดเหลือในกอง", f"{remaining.total()} ใบ")
        col_r2.metric("จะจั่ว (Blade)", f"{blade_count} ใบ")
        col_r3.metric("Required Hearts รวม", f"{sum(combined_req.values())}")

        with st.spinner("กำลังคำนวณ Hypergeometric Probability..."):
            exact = calculate_live_success_probability(state)

        st.markdown(f"### 🎯 โอกาสสำเร็จ (Exact): **{exact.percent():.2f}%**")
        st.progress(min(1.0, exact.probability))
        st.caption(
            f"จาก {exact.total_cases:,} combinations ที่เป็นไปได้ "
            f"→ สำเร็จ {exact.favorable_cases:,} combinations"
        )

        if run_mc:
            with st.spinner(f"รัน Monte Carlo {mc_trials:,} trials..."):
                sim = simulate_live(state, trials=mc_trials, seed=42)
            st.markdown(f"### 🎲 โอกาสสำเร็จ (Monte Carlo, {mc_trials:,} trials): **{sim.percent():.2f}%**")
            st.progress(min(1.0, sim.probability))
            diff = abs(sim.percent() - exact.percent())
            st.caption(
                f"สำเร็จ {sim.successes:,} / {sim.trials:,} trials · "
                f"ต่างจาก exact = {diff:.2f}%"
            )

        # Breakdown
        with st.expander("🔍 รายละเอียดการคำนวณ"):
            st.write("**Remaining deck composition:**")
            rows = []
            for c in HEART_COLORS:
                if remaining.count(c) > 0:
                    rows.append({"Category": color_label(c), "Count": remaining.count(c)})
            if remaining.all_trigger > 0:
                rows.append({"Category": color_label(Color.ALL), "Count": remaining.all_trigger})
            if remaining.non_trigger > 0:
                rows.append({"Category": "⬛ Non-Trigger", "Count": remaining.non_trigger})
            st.table(pd.DataFrame(rows))

            st.write("**Hearts needed from Yell** (หลังหัก basic hearts):")
            needed = state.hearts_needed_from_yell()
            rows2 = []
            for c, n in needed.items():
                if n > 0:
                    rows2.append({"Color": color_label(c), "Needed": n})
            st.table(pd.DataFrame(rows2))


# ==========================================================================
# FOOTER
# ==========================================================================
st.divider()
st.caption(
    "🛠️ สร้างด้วย Python + Streamlit · "
    "Math: Multivariate Hypergeometric Distribution · "
    "สอบทานด้วย Monte Carlo Simulation"
)
