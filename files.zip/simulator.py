"""
Monte Carlo simulator for Love Live OCG Live success probability.
Useful as a cross-check against the exact hypergeometric calculation,
and for handling complex edge cases.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List
import random

from models import Color, GameState
from probability import _check_hearts_satisfy


@dataclass
class SimulationResult:
    probability: float
    successes: int
    trials: int
    draws: int
    deck_size: int

    def percent(self) -> float:
        return self.probability * 100.0


def simulate_live(state: GameState, trials: int = 20000, seed: int | None = None) -> SimulationResult:
    """
    Run Monte Carlo simulation of the Yell phase.
    For each trial: shuffle the remaining deck, draw `blade_count` cards,
    check if the resulting hearts satisfy all Live requirements.
    """
    rng = random.Random(seed)
    remaining = state.remaining_deck()
    N = remaining.total()
    draws = state.stage.blade_count

    if draws <= 0:
        combined = state.combined_requirements()
        satisfied = _check_hearts_satisfy(
            hearts_by_color=state.stage.basic_hearts,
            wildcard_hearts=0,
            requirements=combined,
        )
        return SimulationResult(
            probability=1.0 if satisfied else 0.0,
            successes=trials if satisfied else 0,
            trials=trials,
            draws=0,
            deck_size=N,
        )

    # Build a list of "cards" by category label (we only care about categories)
    deck_list: List[str] = []
    for color in Color.trigger_colors():
        deck_list.extend([color.value] * remaining.count(color))
    deck_list.extend(["all"] * remaining.all_trigger)
    deck_list.extend(["non"] * remaining.non_trigger)

    if draws > N:
        draws = N

    combined_req = state.combined_requirements()
    successes = 0

    for _ in range(trials):
        sample = rng.sample(deck_list, draws)
        # Count draws per category
        drawn: Dict[Color, int] = {}
        all_drawn = 0
        # non not directly used but counted for completeness
        for tag in sample:
            if tag == "all":
                all_drawn += 1
            elif tag == "non":
                pass
            else:
                color = Color(tag)
                drawn[color] = drawn.get(color, 0) + 1

        hearts_total: Dict[Color, int] = {
            color: state.stage.hearts_for_color(color) + drawn.get(color, 0)
            for color in Color.trigger_colors()
        }
        if _check_hearts_satisfy(
            hearts_by_color=hearts_total,
            wildcard_hearts=all_drawn,
            requirements=combined_req,
        ):
            successes += 1

    return SimulationResult(
        probability=successes / trials if trials else 0,
        successes=successes,
        trials=trials,
        draws=draws,
        deck_size=N,
    )
