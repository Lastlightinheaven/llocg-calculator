"""Verify our math reproduces the Google Sheet's 90.85% example."""
import sys
sys.path.insert(0, "/home/claude/lovelive_calculator")

from models import (
    Color, DeckComposition, WaitingRoom, LiveRequirement,
    StageMembers, GameState,
)
from probability import calculate_live_success_probability, simple_target_probability


def test_google_sheet_example():
    """
    From the user's sheet:
      Deck: Red=26, Purple=5, Yellow=14, All=8, Non-Trigger=7  (total 60)
      Already out: Red=15, All=3, Non-Trigger=4, + some Purple/Yellow
                   (total 35 cards out, 25 remaining)
      Draw 10 cards, need 5+ Red (target), max 2 Non-Trigger
      Expected: 90.85%
    """
    # Remaining deck = 25 cards with this breakdown:
    # Red=11, All=5, Non=3, Purple+Yellow=6
    # For the simple_target_probability test:
    remaining = DeckComposition(
        trigger_counts={
            Color.RED: 11,
            Color.PURPLE: 2,   # arbitrary split; only target vs. non-target matters
            Color.YELLOW: 4,
        },
        all_trigger=5,
        non_trigger=3,
    )
    result = simple_target_probability(
        remaining_deck=remaining,
        target_color=Color.RED,
        draws=10,
        target_needed=5,
        non_trigger_max=2,
    )
    print(f"Simple target calc: {result.percent():.2f}%")
    print(f"  favorable = {result.favorable_cases}, total = {result.total_cases}")
    assert abs(result.percent() - 90.85) < 0.01, f"Expected 90.85%, got {result.percent():.2f}%"
    print("✅ simple_target_probability matches Google Sheet (90.85%)")


def test_full_game_state():
    """
    Replicate the same scenario using the full GameState model
    with a multivariate hypergeometric enumeration.
    """
    # Full deck (initial)
    deck = DeckComposition(
        trigger_counts={
            Color.RED: 26,
            Color.PURPLE: 5,
            Color.YELLOW: 14,
        },
        all_trigger=8,
        non_trigger=7,
    )
    assert deck.total() == 60, f"Deck total = {deck.total()}"

    # Cards already out of deck (35 cards)
    # Red out = 15, All out = 3, Non out = 4, Others out = 13
    # Let's distribute 13 as Purple=3, Yellow=10 (just an example)
    waiting = WaitingRoom(
        trigger_counts={
            Color.RED: 15,
            Color.PURPLE: 3,
            Color.YELLOW: 10,
        },
        all_trigger=3,
        non_trigger=4,
    )
    assert waiting.total() == 35

    # Live requiring say: Red=5 and some gray
    # To match the "need 5 Red from Yell and max 2 Non-Trigger", the requirement
    # post-subtracting basic hearts should yield: Red=5, Gray=3 from Yell (10-5-2=3)
    # But wait — sheet's formula: non_trigger_max = draws - (target_needed + other_needed)
    # 10 - 5 - 3 = 2, so we need 3 more hearts "of any type". That's Gray=3 in Live.
    # Or: total required = 8, of which 5 Red, 3 Gray, and basic hearts = 0.
    live = LiveRequirement(
        name="Test Live",
        required_hearts={Color.RED: 5, Color.GRAY: 3},
    )

    # No basic hearts on stage, all 10 blades
    stage = StageMembers(basic_hearts={}, blade_count=10)

    state = GameState(
        deck=deck,
        waiting_room=waiting,
        stage=stage,
        lives=[live],
    )

    remaining = state.remaining_deck()
    print(f"Remaining deck: Red={remaining.count(Color.RED)}, "
          f"Purple={remaining.count(Color.PURPLE)}, "
          f"Yellow={remaining.count(Color.YELLOW)}, "
          f"All={remaining.all_trigger}, Non={remaining.non_trigger}, "
          f"total={remaining.total()}")

    result = calculate_live_success_probability(state)
    print(f"Full game state calc: {result.percent():.2f}%")
    print(f"  favorable = {result.favorable_cases}, total = {result.total_cases}")
    assert abs(result.percent() - 90.85) < 0.01, f"Expected 90.85%, got {result.percent():.2f}%"
    print("✅ Full GameState calculation also matches 90.85%")


if __name__ == "__main__":
    test_google_sheet_example()
    print()
    test_full_game_state()
    print("\n🎉 All tests passed!")
